﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.BizTalk.BaseFunctoids;
using System.Reflection;

namespace $rootnamespace$
{
    [Serializable]
    public class $safeitemname$ : BaseFunctoid
    {
        public $safeitemname$()
            : base()
        {
            //ID for this functoid
            this.ID = 0;

            // resource assembly must be ProjectName.ResourceName if building with VS.Net
            SetupResourceAssembly("$rootnamespace$", Assembly.GetExecutingAssembly());

            //Setup the Name, ToolTip, Help Description, and the Bitmap for this functoid
            SetName("<FUNCTOID_NAME>");
            SetTooltip("<FUNCTOID_TOOLTIP>");
            SetDescription("<FUNCTOID_DESCRIPTION>");
            SetBitmap("<FUNCTOID_BITMAP>");

            //category for this functoid. This functoid goes under the String Functoid Tab in the
            this.Category = FunctoidCategory.None;

            // Set the limits for the number of input parameters. This example: 1 parameter
            this.SetMinParams(1);
            this.SetMaxParams(1);

            // Add one line of code as set out below for each input param. For multiple input params, each line would be identical.
            AddInputConnectionType(ConnectionType.All); //first input

            // The functoid output can go to any node type.
            this.OutputConnectionType = ConnectionType.All;

            // Set the function name that is to be called when invoking this functoid.
            // To test the map in Visual Studio, this functoid does not need to be in the GAC.
            // If using this functoid in a deployed BizTalk app. then it must be in the GAC
            SetExternalFunctionName(GetType().Assembly.FullName, GetType().FullName, "MyFunction");

            //If you use SetScriptBuffer you don't need to use SetExternalFunctionName and the
            //functoid don't need to be added to GAC
            //SetScriptBuffer(ScriptType.CSharp, this.GetCSharpBuffer());
            //HasSideEffects = false;
        }

        /// <summary>
        /// The real operation to be executed by the functoid
        /// You need change this code and add your logic here
        /// </summary>
        public string MyFunction(string input)
        {
            return input;
        }

        /// <summary>
        /// You need change this code and add your logic here
        /// Don't change the name of the function, only the content
        /// </summary>
        //private string GetCSharpBuffer()
        //{
        //    StringBuilder builder = new StringBuilder();
        //    builder.Append("public string MyFunction(string input)\n");
        //    builder.Append("{\n");
        //    builder.Append("\treturn input;\n");
        //    builder.Append("}\n");
        //    return builder.ToString();
        //}

    }
}
